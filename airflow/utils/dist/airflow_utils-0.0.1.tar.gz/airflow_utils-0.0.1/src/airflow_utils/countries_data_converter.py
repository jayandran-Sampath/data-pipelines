from pyspark.sql import SparkSession
import findspark

def convertDataFromSource():
  findspark.init()
  spark = SparkSession\
            .builder\
            .appName("SparkWriterJob")\
            .config("spark.sql.shuffle.partitions", 2)\
            .config("spark.default.parallelism", 2)\
            .master("local[2]")\
            .getOrCreate()
  raw_data = spark\
                .read\
                .option("inferSchema", "true")\
                .option("header", "true")\
                .csv("../dags/countries_data/input/airflow_data-extract.csv")

  raw_data = raw_data.drop('Country Code')
  recent_data = raw_data.where(raw_data.Year >= 2010)
  recent_data.write \
      .option("compression", "gzip") \
      .partitionBy("Year") \
      .parquet(path="../dags/countries_data/stagging",
               mode="overwrite");
  spark.stop()